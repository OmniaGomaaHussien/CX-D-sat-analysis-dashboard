# Customer Experience (CX) & DSAT Analysis Dashboard

## Project overview
A portfolio project demonstrating how a CX/Data Analyst can investigate customer dissatisfaction (DSAT), identify operational drivers, and communicate findings through a Power BI dashboard.

**Business scenario:** A fictional online food delivery company is experiencing customer dissatisfaction and wants to understand the main complaint drivers, channel differences, resolution-time patterns, and repeat contacts.

> **Data notice:** All records and results in this repository are synthetic and created for portfolio/learning purposes. They do not represent a real company or actual business performance. Do not present the illustrative impact as a measured company result.

## Business problem
High DSAT rates with unclear root causes make it difficult for CX and Operations teams to prioritize improvements.

## Tools
- Power BI Desktop — data model, DAX measures, interactive report
- Excel — data review and validation
- CSV — source and cleaned datasets

## Dataset
- 2,000 synthetic customer interaction records
- Date range: 2026-01-01 to 2026-06-30
- Channels: Chat, Phone, Email, In-App
- Issue categories: Late Delivery, Missing Items, Incorrect Order, Poor Agent Support, Refund Delay, App/Technical Issue
- CSAT rating: 1 to 5

### DSAT definition
For this project, a response is classified as dissatisfied when **CSAT_Rating is 1 or 2**. DSAT Rate = dissatisfied interactions / total interactions.

## Illustrative headline metrics
- Total interactions: 2,000
- Dissatisfied interactions: 789
- DSAT rate: 39.5%
- Repeat contacts: 471
- Repeat contact rate: 23.5%
- Average resolution time: 19.0 minutes
- Average CSAT rating: 3.13 / 5

These values are calculated from the synthetic dataset and may change if you modify the data.

## Repository files
| File | Description |
|---|---|
| `cx_feedback_raw.csv` | Original synthetic source data |
| `cx_feedback_cleaned.csv` | Prepared data with analytical flags |
| `CX_DSAT_Analysis.xlsx` | Excel workbook with raw, cleaned, KPI and dictionary sheets |
| `DAX_Measures.dax` | Core Power BI measures |
| `Power_Query_M_Code.txt` | Optional Power Query transformation example |

## How to build the Power BI dashboard
1. Open **Power BI Desktop**.
2. Select **Get data → Text/CSV** and import `cx_feedback_cleaned.csv`.
3. Select **Load**. Confirm `Interaction_Date` is Date, `CSAT_Rating` is Whole number, and `Resolution_Time_Min` is Decimal number.
4. Open `DAX_Measures.dax` and create each measure using **Modeling → New measure**.
5. Create the report visuals listed below.
6. Add slicers for `Interaction_Date`, `Region`, `Channel`, and `Customer_Segment`.
7. Save the report as `CX_DSAT_Dashboard.pbix`.

## Suggested dashboard layout

### Top row — KPI cards
- Total Interactions
- DSAT Rate
- Repeat Contact Rate
- Average Resolution Time

### Middle row — what is driving dissatisfaction?
- Clustered bar chart: DSAT Rate by `Issue_Category`
- Column chart: DSAT Rate by `Channel`
- Line chart: DSAT Rate by month (`Interaction_Date`)

### Bottom row — operational deep dive
- Bar chart: Average Resolution Time by `Issue_Category`
- Stacked column chart: `CSAT_Status` by `Channel`
- Table: `Issue_Category`, Total Interactions, Dissatisfied Interactions, DSAT Rate, Average Resolution Time

**Tip:** For the issue and channel comparisons, use the `DSAT Rate` measure rather than raw dissatisfied counts so categories of different sizes can be compared fairly.

## Analysis questions
1. Which issue category has the highest DSAT rate?
2. Which channel has the highest DSAT rate?
3. Does DSAT tend to be higher when resolution time increases?
4. Which issue categories contribute most to repeat contacts?
5. Are there monthly changes that need operational investigation?

## Example insight-writing format
Use the dashboard results to write evidence-based statements:
- **Finding:** [Issue category] has the highest DSAT rate at [X%].
- **Evidence:** It accounts for [N] dissatisfied interactions out of [M] total interactions.
- **Recommendation:** Review the process, identify the failure point, and monitor the issue weekly.
- **Expected business value:** Better prioritization and fewer avoidable repeat contacts.

Do not claim that the dashboard itself reduced complaints. A reduction in complaints is an outcome that must be measured after an intervention and compared with a baseline.

## Suggested portfolio project description
**Customer Experience (CX) & DSAT Analysis Dashboard | Power BI, Excel**
- Created and analyzed a 2,000-record synthetic customer feedback dataset to investigate customer dissatisfaction.
- Prepared data and developed calculated fields to classify DSAT, customer satisfaction, and repeat contacts.
- Defined DAX measures to monitor DSAT rate, repeat contact rate, CSAT rating, and resolution time.
- Designed an interactive dashboard to compare dissatisfaction across issue categories, support channels, regions, and time.
- Developed data-driven recommendations to help CX and Operations teams prioritize recurring service issues.

## Limitations
This is a synthetic portfolio case study. The dataset is randomly generated with intentionally varied patterns to support analysis practice. Correlation between resolution time and DSAT does not prove causation. The project does not measure real-world complaint reduction or financial impact.
